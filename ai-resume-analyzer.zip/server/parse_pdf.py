import sys
import os
import subprocess

# Auto-install pypdf if not present
try:
    import pypdf
except ImportError:
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", "pypdf", "--quiet"])
        import pypdf
    except Exception as e:
        print(f"Error: Failed to auto-install pypdf library: {e}", file=sys.stderr)
        sys.exit(1)

def extract_text(pdf_path):
    reader = pypdf.PdfReader(pdf_path)
    text = ""
    for page in reader.pages:
        page_text = page.extract_text()
        if page_text:
            text += page_text + "\n"
    return text.strip()

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python3 parse_pdf.py <pdf_path>")
        sys.exit(1)
    
    pdf_path = sys.argv[1]
    if os.path.exists(pdf_path):
        try:
            text = extract_text(pdf_path)
            # Print the extracted text to standard output so Node can consume it
            print(text)
        except Exception as e:
            print(f"Error parsing PDF: {e}", file=sys.stderr)
            sys.exit(1)
    else:
        print(f"Error: File not found at {pdf_path}", file=sys.stderr)
        sys.exit(1)
