export interface Candidate {
  name: string;
  email: string;
  phone: string;
  currentTitle?: string;
  summary: string;
  yearsOfExperience: number;
  education?: string[];
}

export interface CompetencyDimension {
  name: string;
  score: number; // 1-10 rating
  feedback: string;
}

export interface CorporateSectorFit {
  overallStatus: string;
  suitabilityScore: number; // 0-100 rating
  analysisOverview: string;
  dimensions: CompetencyDimension[];
}

export interface JobMatching {
  matchScore: number; // 0-100 score
  matchedSkills: string[];
  missingSkills: string[];
  bonusSkills: string[];
  fitSummary: string;
}

export interface ImprovementSuggestion {
  category: string;
  suggestion: string;
  why: string;
  priority: string; // High, Medium, Info
}

export interface AnalysisPayload {
  candidate: Candidate;
  extractedSkills: string[];
  corporateSectorFit: CorporateSectorFit;
  jobMatching: JobMatching;
  improvementSuggestions: ImprovementSuggestion[];
}

export interface AnalysisResponse {
  success: boolean;
  analysis?: AnalysisPayload;
  error?: string;
}
