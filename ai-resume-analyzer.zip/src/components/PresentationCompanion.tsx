import React, { useState, useEffect } from "react";
import {
  Play,
  Pause,
  RotateCcw,
  Users,
  Clock,
  Sparkles,
  CheckCircle,
  HelpCircle,
  Mic,
  ChevronRight,
  Tv,
  MessageSquare,
  BookOpen,
  ChevronDown,
  Volume2
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface ScriptLine {
  id: number;
  speakerId: string;
  speakerName: string;
  role: string;
  avatarColor: string;
  slideTitle: string;
  dialogue: string;
  actionCue: string;
  visualTrigger: string;
  durationEst: string; // e.g. "45s"
}

export default function PresentationCompanion() {
  // Presentation States
  const [selectedRole, setSelectedRole] = useState<string>("ALL");
  const [activeLineId, setActiveLineId] = useState<number>(1);
  const [completedLines, setCompletedLines] = useState<number[]>([]);
  const [timerRunning, setTimerRunning] = useState<boolean>(false);
  const [elapsedTime, setElapsedTime] = useState<number>(0);
  const [activeTab, setActiveTab] = useState<"script" | "deck" | "qa">("script");
  
  // Custom Notes state
  const [presenterNotes, setPresenterNotes] = useState<string>(
    "Keep eye contact with judges. Presenter 3 should prepare a demo PDF beforehand."
  );

  // Q&A Flashcard state
  const [revealedQaId, setRevealedQaId] = useState<number | null>(null);

  // Rehearsal timer tick
  useEffect(() => {
    let interval: NodeJS.Timeout | null = null;
    if (timerRunning) {
      interval = setInterval(() => {
        setElapsedTime((prev) => prev + 1);
      }, 1000);
    }
    return () => {
      if (interval) clearInterval(interval);
    };
  }, [timerRunning]);

  // Format seconds to MM:SS
  const formatTime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const secs = sec % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const resetTimer = () => {
    setTimerRunning(false);
    setElapsedTime(0);
  };

  // 6 Presenter Profiles
  const presenters = [
    { id: "ALL", name: "All Speakers", role: "Full Team Synergy", color: "bg-slate-800 text-white" },
    { id: "P1", name: "Presenter 1 (Lead)", role: "Product Strategy & Vision", color: "bg-blue-500/20 text-blue-300 border-blue-500/30" },
    { id: "P2", name: "Presenter 2 (UX)", role: "Visual System & UX Architect", color: "bg-teal-500/20 text-teal-300 border-teal-500/30" },
    { id: "P3", name: "Presenter 3 (Parser)", role: "Python NLP & Regex Analyst", color: "bg-indigo-500/20 text-indigo-300 border-indigo-500/30" },
    { id: "P4", name: "Presenter 4 (AI)", role: "ML Similarity & Cognitive Alignment", color: "bg-purple-500/20 text-purple-300 border-purple-500/30" },
    { id: "P5", name: "Presenter 5 (Coach)", role: "Career Coach & Growth Strategist", color: "bg-orange-500/20 text-orange-300 border-orange-500/30" },
    { id: "P6", name: "Presenter 6 (Ops)", role: "Production DevOps & Cloud Scaling", color: "bg-pink-500/20 text-pink-300 border-pink-500/30" },
  ];

  // Professional Script written specifically for the CorporateFit App
  const scriptLines: ScriptLine[] = [
    {
      id: 1,
      speakerId: "P1",
      speakerName: "Presenter 1 (Lead)",
      role: "Product Strategy & Vision",
      avatarColor: "bg-blue-500",
      slideTitle: "Slide 1: The Corporate Talent Blindspot",
      dialogue: "Good morning distinguished judges and stakeholders. Recruiters today face an expensive problem: they receive hundreds of resumes per job, but traditional Applicant Tracking Systems reject qualified talent due to dry word-matching deficits. We built CorporateFit AI to solve this. It provides dual-layer validation: a server-side Python PDF parsing engine combined with Gemini cognitive intelligence. In just 90 seconds, we will show you how our tool bridges this corporate divide.",
      actionCue: "Stand center-stage confidently. Project your voice. Hold clicker high.",
      visualTrigger: "Point to the static empty state of CorporateFit AI. Introduce the title 'CorporateFit AI Analyzer'.",
      durationEst: "35s"
    },
    {
      id: 2,
      speakerId: "P2",
      speakerName: "Presenter 2 (UX)",
      role: "Visual System & UX Architect",
      avatarColor: "bg-teal-500",
      slideTitle: "Slide 2: Craftsmanship & Cognitive Design",
      dialogue: "To ensure maximum productivity, we transcended standard grey grid tables. Our UI is designed with an immersive slate-dark theme, featuring high-contrast typography pairing, elegant 'Space Grotesk' headings, and high-contrast feedback indicators. Notice the responsive bento layout and our elegant drag-and-drop system. Let's upload a PDF resume of an actual candidate to see the live system translate raw bytes into executive-ready metrics.",
      actionCue: "Walk towards the desk. Guide the audience's eyes with hand guestures over the upload card.",
      visualTrigger: "Perform drag-and-drop file upload of the candidate resume PDF, selecting the 'Software Engineer II' benchmark role.",
      durationEst: "40s"
    },
    {
      id: 3,
      speakerId: "P3",
      speakerName: "Presenter 3 (Parser)",
      role: "Python NLP & Regex Analyst",
      avatarColor: "bg-indigo-500",
      slideTitle: "Slide 3: High-Resilience Parsing Engine",
      dialogue: "While other solutions break when encountering compressed PDF files or missing system libraries, CorporateFit AI utilizes an ultra-resilient Python execution sandbox on the backend. When a PDF is received, we decompress the flate stream chunks to grep text coordinates. If libraries fail, our secure parser automatically falls back to raw-binary regex byte crawlers to guarantee a 100% extraction success rate. No missing data, no silent crashes.",
      actionCue: "Point back to the monitor. Speak in an encouraging, technical, highly precise tone.",
      visualTrigger: "Click 'Run Smart Diagnostics'. Let the audience watch the animated loading messages scroll in real time.",
      durationEst: "45s"
    },
    {
      id: 4,
      speakerId: "P4",
      speakerName: "Presenter 4 (AI)",
      role: "ML Similarity & Cognitive Alignment",
      avatarColor: "bg-purple-500",
      slideTitle: "Slide 4: High-Dimensional Alignment Metrics",
      dialogue: "Once parsed, the candidate's profile is compiled. As you see on the dashboard, we generate two distinct metrics. First: the specific JD Requirements Match, measuring direct technical alignments. Second: our Corporate Sector Fit. Rather than simple keywords, we score the candidate across 5 sophisticated soft competency dimensions, giving recruiters a 360-degree blueprint of professional posture, agile agility, and structural communication.",
      actionCue: "Focus on the two gauges on screen. Hover over the corporate soft skills scores to highlight details.",
      visualTrigger: "Draw attention to the matching circular meters (e.g. 84%) and the Corporate Competency bar widgets.",
      durationEst: "45s"
    },
    {
      id: 5,
      speakerId: "P5",
      speakerName: "Presenter 5 (Coach)",
      role: "Career Coach & Growth Strategist",
      avatarColor: "bg-orange-500",
      slideTitle: "Slide 5: Actionable Optimization Loop",
      dialogue: "But we don't just score candidates—we elevate them. Below, our platform reveals a precise skillset gap matcher: categorizing matched, critical deficits, and bonus skills. Finally, our interactive Suggestions Checklist provides high, medium, and low priority checklists. Candidates or recruiters can check off these micro-goals with absolute clarity, creating a strategic roadmap for leveling up professional credentials to match high-tier industry expectations.",
      actionCue: "Open the suggestions checklist dropdown. Check off one or two items to show interactivity.",
      visualTrigger: "Expand a diagnostic suggestion card to show the detailed 'Why this matters' sub-text.",
      durationEst: "40s"
    },
    {
      id: 6,
      speakerId: "P6",
      speakerName: "Presenter 6 (Ops)",
      role: "Production DevOps & Cloud Scaling",
      avatarColor: "bg-pink-500",
      slideTitle: "Slide 6: Scalability & Enterprise Future",
      dialogue: "Under the hood, CorporateFit is enterprise-ready. Designed on top of lightweight Node.js and compiled into a single CommonJS server bundle with esbuild, it bypasses Node's ESM resolution friction, reducing deployment start times to under 150 milliseconds. It can scale-to-zero in serverless containers and easily bridges into Firestore for persistent candidate pipelines. Our roadmap includes automated bulk multi-PDF comparisons.",
      actionCue: "Re-align beside Presenter 1. Change your voice into high-energy, summary mode.",
      visualTrigger: "Hover over the footer showing UTC indicators, and transition your hands back to the entire dashboard.",
      durationEst: "35s"
    },
    {
      id: 7,
      speakerId: "P1",
      speakerName: "Presenter 1 (Lead)",
      role: "Product Strategy & Vision",
      avatarColor: "bg-blue-500",
      slideTitle: "Final Slide: The Closing Value Proposition",
      dialogue: "To conclude: CorporateFit AI replaces guesswork with rigorous, elegant engineering. It respects candidate time, improves recruiter output by 400%, and builds cohesive, high-performing corporate teams. We are CorporateFit. Thank you, and we welcome your questions! ",
      actionCue: "All 6 presenters bow together slightly, smiling. Direct attention to the judges.",
      visualTrigger: "Show the complete scored dashboard in all its glory. Maintain the gorgeous slate-themed screen.",
      durationEst: "30s"
    }
  ];

  // Q&A Prep Flashcards
  const qaCards = [
    {
      id: 1,
      question: "What happens if a PDF corresponds to a complex multi-column design resume? Can Python read it?",
      answer: "Great question! Multi-column PDFs often lead to scrambled reads in basic readers because text is processed left-to-right across columns. CorporateFit mitigates this by utilising standard pypdf grid margins. If layout scrambling persists, our Gemini model serves as a layout stabilizer, reading unstructured tokens and contextually rebuilding chronological career timelines."
    },
    {
      id: 2,
      question: "How secure is candidate data in this flow? Is resume text sent to third-parties?",
      answer: "CorporateFit prioritizes privacy. The PDF extraction executes locally inside our server-side Node-Python sandbox container. No third-party OCR services are used. Only the sanitized plain-text tokens are sent server-to-server to the secure Gemini API using authorized environment variables. This protects raw candidate PII from client-side vector exposures."
    },
    {
      id: 3,
      question: "How does the Corporate Sector Fit score get computed? Is it biased?",
      answer: "The Corporate Sector Fit evaluates 5 critical core dimensions (such as Agile Process Mindset, Leadership & Mentorship, and Executive Delivery Presence) based on structured linguistic triggers. Instead of rejecting profiles with low scores, the algorithm acts objectively and generates high-fidelity suggestions to tell the candidate precisely what phrasing or proof they need to insert is."
    },
    {
      id: 4,
      question: "Why did you build the backend with separate Python and Node scripts?",
      answer: "We chose a hybrid architecture. Node.js is unmatched for real-time asset serving, request routing, and web UI. However, Python has the industry-standard binary compression libraries necessary for parsing variable PDF schemas. Executing client requests in Node and calling a focused, resilient sandboxed Python utility allows us to remain fully scalable and maintain extreme fast reaction speeds."
    }
  ];

  const filteredLines = scriptLines.filter(
    (line) => selectedRole === "ALL" || line.speakerId === selectedRole
  );

  const toggleLineCompleted = (id: number) => {
    setCompletedLines((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const currentActiveLine = scriptLines.find((l) => l.id === activeLineId) || scriptLines[0];

  return (
    <div className="bg-slate-900 border border-white/10 rounded-3xl p-6 shadow-2xl relative overflow-hidden">
      
      {/* Decorative accent lines */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-blue-500/10 rounded-full blur-2xl pointer-events-none"></div>
      <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none"></div>

      {/* Header and Rehearsal Widgets */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-white/10 pb-5 mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-gradient-to-br from-indigo-500 to-purple-500 rounded-xl text-white">
            <Tv className="w-5.5 h-5.5" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight flex items-center gap-2">
              Presentation Mode <span className="text-[10px] bg-indigo-500/20 text-indigo-300 font-mono font-bold px-2 py-0.5 rounded-full border border-indigo-500/30">6-Presenter Special</span>
            </h2>
            <p className="text-xs text-white/60">
              Interactive team rehearsal scripts, action cues, pacing tracking, and Q&A flashcards
            </p>
          </div>
        </div>

        {/* Rehearsal Pacing Timer */}
        <div className="flex items-center gap-3.5 bg-white/5 border border-white/10 p-2 px-3 rounded-2xl">
          <div className="flex items-center gap-1.5 font-mono text-xs font-semibold text-white">
            <Clock className="w-4 h-4 text-indigo-400" />
            <span>{formatTime(elapsedTime)}</span>
          </div>
          
          <div className="h-4 w-[1px] bg-white/10"></div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setTimerRunning(!timerRunning)}
              className={`p-1.5 rounded-lg cursor-pointer transition-colors ${
                timerRunning ? "bg-amber-500/20 hover:bg-amber-500/30 text-amber-300" : "bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300"
              }`}
              title={timerRunning ? "Pause timer" : "Start rehearsal stopwatch"}
            >
              {timerRunning ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            </button>

            <button
              onClick={resetTimer}
              className="p-1.5 bg-white/5 hover:bg-white/10 text-white/60 hover:text-white rounded-lg cursor-pointer transition-colors"
              title="Reset stopwatch"
            >
              <RotateCcw className="w-3.5 h-3.5" />
            </button>
          </div>

          <span className="text-[9px] font-mono font-bold text-white/40 hidden sm:inline-block">
            Target Pace: <span className="text-indigo-300">4:30s</span>
          </span>
        </div>
      </div>

      {/* Tabs navigation */}
      <div className="flex bg-white/5 border border-white/10 p-1 rounded-xl mb-6">
        <button
          onClick={() => setActiveTab("script")}
          className={`flex-1 py-2 cursor-pointer text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-all ${
            activeTab === "script" ? "bg-indigo-600 text-white shadow-xs" : "text-white/60 hover:text-white"
          }`}
        >
          <Mic className="w-4 h-4" />
          Interactive Script
        </button>
        <button
          onClick={() => setActiveTab("deck")}
          className={`flex-1 py-2 cursor-pointer text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-all ${
            activeTab === "deck" ? "bg-indigo-600 text-white shadow-xs" : "text-white/60 hover:text-white"
          }`}
        >
          <Tv className="w-4 h-4" />
          Slide Deck Companion
        </button>
        <button
          onClick={() => setActiveTab("qa")}
          className={`flex-1 py-1.5 cursor-pointer text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-all ${
            activeTab === "qa" ? "bg-indigo-600 text-white shadow-xs" : "text-white/60 hover:text-white"
          }`}
        >
          <HelpCircle className="w-4 h-4" />
          Judge Q&A Flashcards
        </button>
      </div>

      {/* Tab Contents: 1. Script */}
      {activeTab === "script" && (
        <div className="space-y-6">
          
          {/* Quick Role Select Filter */}
          <div className="bg-white/5 border border-white/5 rounded-2xl p-4">
            <span className="text-[10px] font-bold text-white/50 block font-mono uppercase mb-2.5 tracking-wider">
              Filter by Role: Rehearse Your lines
            </span>
            <div className="flex flex-wrap gap-1.5">
              {presenters.map((role) => (
                <button
                  key={role.id}
                  onClick={() => setSelectedRole(role.id)}
                  className={`px-3 py-1.5 rounded-lg border text-xs font-medium cursor-pointer transition-all ${
                    selectedRole === role.id
                      ? "bg-indigo-600 text-white border-indigo-500 shadow-md"
                      : "bg-white/5 text-white/70 border-white/5 hover:bg-white/10 hover:text-white"
                  }`}
                >
                  {role.name}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
            
            {/* Left Script panel: Speeches scroll list */}
            <div className="lg:col-span-2 space-y-4 max-h-[500px] overflow-y-auto pr-1">
              <AnimatePresence mode="popLayout">
                {filteredLines.map((line, idx) => {
                  const isCompleted = completedLines.includes(line.id);
                  const isCurrentlyActive = activeLineId === line.id;
                  
                  return (
                    <motion.div
                      key={line.id}
                      layoutId={`line-${line.id}`}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0 }}
                      onClick={() => setActiveLineId(line.id)}
                      className={`p-4 border rounded-2xl text-left cursor-pointer transition-all ${
                        isCurrentlyActive
                          ? "bg-indigo-950/40 border-indigo-500/70 shadow-lg shadow-indigo-900/10"
                          : "bg-white/5 border-white/5 hover:bg-white/8 hover:border-white/10"
                      }`}
                    >
                      <div className="flex items-center justify-between gap-3 mb-2.5">
                        <div className="flex items-center gap-2">
                          <div className={`w-2.5 h-2.5 rounded-full ${line.avatarColor}`}></div>
                          <span className="text-xs font-bold text-white">{line.speakerName}</span>
                          <span className="text-[9px] bg-white/5 text-white/40 block px-2 py-0.5 rounded-md border border-white/5 font-mono">
                            Est: {line.durationEst}
                          </span>
                        </div>

                        <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
                          <button
                            onClick={() => toggleLineCompleted(line.id)}
                            className={`p-1 rounded-sm cursor-pointer transition-colors ${
                              isCompleted ? "text-emerald-400" : "text-white/20 hover:text-white/50"
                            }`}
                            title={isCompleted ? "Mark as uncompleted" : "Mark as completed/rehearsed"}
                          >
                            <CheckCircle className="w-4 h-4" />
                          </button>
                        </div>
                      </div>

                      <h4 className="text-xs font-semibold text-indigo-300 font-mono mb-1.5 text-left">
                        {line.slideTitle}
                      </h4>

                      <p className={`text-xs leading-relaxed text-left font-normal ${
                        isCompleted ? "text-white/30 line-through" : "text-white/80"
                      }`}>
                        "{line.dialogue}"
                      </p>

                      <div className="mt-3 pt-2.5 border-t border-white/5 grid grid-cols-1 sm:grid-cols-2 gap-2 text-[10px]">
                        <div>
                          <span className="text-amber-300 font-semibold uppercase font-mono tracking-wider">Action Cue: </span>
                          <span className="text-white/60">{line.actionCue}</span>
                        </div>
                        <div>
                          <span className="text-emerald-300 font-semibold uppercase font-mono tracking-wider">Show On Screen: </span>
                          <span className="text-white/60">{line.visualTrigger}</span>
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>
            </div>

            {/* Right Dashboard checklist/prompter guide */}
            <div className="lg:col-span-1 space-y-4">
              
              {/* Presenter Active Detail Prompter */}
              <div className="p-5 bg-white/5 border border-white/5 rounded-2xl space-y-4 text-left">
                <span className="text-[10px] font-bold text-indigo-400 font-mono tracking-wider uppercase block">
                  Teleprompter Focal Card
                </span>
                
                <div className="flex items-center gap-3 pb-3 border-b border-white/5">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center text-xs font-extrabold ${currentActiveLine.avatarColor} text-white shrink-0`}>
                    {currentActiveLine.speakerId}
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white">{currentActiveLine.speakerName}</h3>
                    <p className="text-[10px] text-indigo-300 font-mono font-medium">{currentActiveLine.role}</p>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[10px] font-bold text-white/40 block font-mono uppercase">
                    Your Dialogue
                  </span>
                  <div className="p-3 bg-indigo-950/30 border border-indigo-500/20 rounded-xl">
                    <p className="text-xs text-indigo-100 leading-relaxed font-normal">
                      "{currentActiveLine.dialogue}"
                    </p>
                  </div>
                </div>

                <div className="space-y-2 text-[11px] pt-1.5">
                  <div className="p-2.5 bg-amber-500/10 border border-amber-500/20 rounded-lg text-amber-200">
                    <span className="font-bold uppercase font-mono tracking-wider block text-[9px] mb-0.5">Physical Cue:</span>
                    {currentActiveLine.actionCue}
                  </div>
                  <div className="p-2.5 bg-emerald-500/10 border border-emerald-500/20 rounded-lg text-emerald-250">
                    <span className="font-bold uppercase font-mono tracking-wider block text-[9px] mb-0.5">Screen Assist:</span>
                    {currentActiveLine.visualTrigger}
                  </div>
                </div>

                <div className="pt-2 px-1 flex items-center justify-between text-[10px] text-white/40">
                  <span>Scroll line to select</span>
                  <span className="font-mono text-indigo-300 font-bold">{currentActiveLine.durationEst} target</span>
                </div>
              </div>

              {/* Presenter Notes */}
              <div className="p-5 bg-white/5 border border-white/5 rounded-2xl text-left space-y-2.5">
                <span className="text-[10px] font-bold text-white/40 block font-mono uppercase">
                  Rehearsal Team Notes
                </span>
                <textarea
                  rows={3}
                  value={presenterNotes}
                  onChange={(e) => setPresenterNotes(e.target.value)}
                  className="w-full text-xs p-2.5 bg-slate-950/50 border border-white/10 rounded-xl text-white/80 focus:outline-hidden text-left focus:ring-1 focus:ring-indigo-500 font-sans"
                  placeholder="Type shared presenter tips or timing guidelines here..."
                />
                <p className="text-[9px] text-white/30 truncate">
                  Changes remain saved until workspace refreshes
                </p>
              </div>

            </div>

          </div>

        </div>
      )}

      {/* Tab Contents: 2. Deck Outline */}
      {activeTab === "deck" && (
        <div className="p-2 space-y-6 text-left">
          <div className="p-4 bg-indigo-950/20 border border-indigo-500/30 rounded-2xl flex gap-3.5 items-start">
            <BookOpen className="w-5 h-5 text-indigo-400 shrink-0 mt-0.5" />
            <div>
              <span className="text-xs font-semibold text-indigo-200 block">How to Present This App</span>
              <p className="text-xs text-white/60 leading-relaxed mt-0.5 font-normal">
                Use this slide-by-slide sequence. Keep the app open in another browser window so a team member can click buttons and toggle templates instantly as speakers change!
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {scriptLines.map((line) => (
              <div key={line.id} className="p-4 bg-white/5 border border-white/5 rounded-2xl space-y-3 shrink-0 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between gap-2 border-b border-white/5 pb-2 mb-2">
                    <span className="text-xs font-bold text-white truncate max-w-[150px]">{line.slideTitle}</span>
                    <span className="text-[9px] font-mono text-indigo-400 bg-indigo-500/10 px-1.5 py-0.5 rounded-sm shrink-0 uppercase font-bold">{line.speakerId}</span>
                  </div>
                  
                  <div className="space-y-1.5">
                    <span className="text-[9px] text-white/35 font-mono uppercase block font-bold">Slide content & goals</span>
                    <p className="text-xs text-white/75 leading-relaxed font-normal">
                      {line.visualTrigger}
                    </p>
                  </div>
                </div>

                <div className="pt-2 bg-slate-950/40 p-2.5 border border-white/5 rounded-xl font-mono text-[9px] text-white/50">
                  <span className="text-amber-400 font-bold block uppercase tracking-wider text-[8px] mb-0.5">Presentation Cue</span>
                  {line.actionCue}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab Contents: 3. Q&A Prep */}
      {activeTab === "qa" && (
        <div className="space-y-4 text-left">
          <div className="p-4 bg-emerald-950/20 border border-emerald-500/30 rounded-2xl flex gap-3.5 items-start">
            <MessageSquare className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            <div>
              <span className="text-xs font-semibold text-emerald-250 block">Handle Audience / Judge Q&A</span>
              <p className="text-xs text-white/60 leading-relaxed mt-0.5 font-normal font-sans">
                Judges love technical depth and security clarification. Rehearse these answers so your engineering decisions sound solid, highly precise, and completely secure.
              </p>
            </div>
          </div>

          <div className="space-y-3">
            {qaCards.map((qa) => {
              const isOpen = revealedQaId === qa.id;
              return (
                <div
                  key={qa.id}
                  onClick={() => setRevealedQaId(isOpen ? null : qa.id)}
                  className="bg-white/5 border border-white/5 hover:border-white/10 rounded-2xl p-4.5 cursor-pointer transition-all"
                >
                  <div className="flex items-center justify-between gap-3 font-semibold text-xs md:text-sm text-white">
                    <span className="flex items-center gap-2.5 text-left leading-relaxed">
                      <HelpCircle className="w-4 h-4 shrink-0 text-indigo-400" />
                      {qa.question}
                    </span>
                    <ChevronDown className={`w-4 h-4 shrink-0 text-white/30 transition-transform ${isOpen ? "rotate-180" : ""}`} />
                  </div>

                  <AnimatePresence>
                    {isOpen && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden"
                      >
                        <div className="mt-4 pt-3.5 border-t border-white/10 text-xs text-white/70 leading-relaxed font-sans font-normal p-3 bg-slate-900 rounded-xl">
                          <span className="text-emerald-400 font-extrabold font-mono uppercase tracking-wider block text-[10px] mb-1">
                            Recommended Answer Strategy:
                          </span>
                          {qa.answer}
                        </div>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              );
            })}
          </div>
        </div>
      )}

    </div>
  );
}
