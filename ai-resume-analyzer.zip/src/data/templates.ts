export interface JobTemplate {
  id: string;
  title: string;
  department: string;
  description: string;
}

export const jobTemplates: JobTemplate[] = [
  {
    id: "software-engineer",
    title: "Software Engineer II",
    department: "Tech & Corporate Services",
    description: `About the Role:
We are seeking a highly capable Software Engineer II to join our corporate infrastructure team. You will build and optimize software solutions that scale, collaborating with developers, product managers, and enterprise business stakeholders.

Required Technical Skills:
- React.js, TypeScript, and modern front-end state management
- Node.js, Express, and building RESTful web services/APIs
- Relational databases (PostgreSQL/MySQL) or NoSQL databases
- Docker, CI/CD pipelines, and cloud services (AWS, GCP, or Azure)
- Unit testing with Jest or Mocha

Corporate & Professional Competencies:
- Strong written and verbal communication style for aligning with non-technical stakeholders
- Ability to write technical documentation and engineering design guides
- Adherence to agile processes, sprint planning, and professional code review standards
- Highly analytical problem-solving and collaboration with a cross-functional squad`
  },
  {
    id: "strategy-consultant",
    title: "Corporate Strategy Consultant",
    department: "Business Operations & Strategy",
    description: `About the Role:
As a Corporate Strategy Consultant, you will deliver data-driven analytical insights, guide strategic initiatives, and draft corporate business cases. You will collaborate directly with executive leadership, managing enterprise-level projects.

Key Requirements & Preferred Skills:
- Professional management consulting, financial modeling, or strategic planning background
- Advanced spreadsheet modeling (Excel, financial planning tools) and metrics formulation
- Preparing high-quality presentation materials suitable for senior leadership and C-level board members
- Leading project squads and aligning multi-functional stakeholders
- Data analysis tools (SQL, Tableau, or PowerBI)
- Corporate business etiquette, professional composure, and client-facing communication`
  },
  {
    id: "financial-analyst",
    title: "Senior Corporate Financial Analyst",
    department: "Corporate Finance & Treasury",
    description: `About the Role:
We are looking for a Senior Financial Analyst to lead our budget modeling, forecast analysis, and quarterly business reviews. You will serve as the finance partner to multiple business lines, translating operational activities into financial matrices.

Duties & Skills Required:
- Financial forecasting, budget tracking, variance analysis, and cost-benefit assessments
- Expert knowledge of corporate finance principles, accounting standards, and treasury processes
- Advanced Excel modeling skills, SQL querying capability, and ERP software knowledge
- Generating clear presentation decks explaining financial performance and risks to executives
- High attention to detail, strong business ethics, and accountability`
  },
  {
    id: "marketing-manager",
    title: "Enterprise Product Marketing Manager",
    department: "Brand & Corporate Communications",
    description: `About the Role:
Seeking an experienced Product Marketing Manager to craft the positioning, messaging, and go-to-market strategies for our B2B corporate software suite. You will collaborate with product management, sales teams, and corporate communications.

Skills and Profile Requirements:
- Crafting clear B2B value propositions, case studies, and corporate sales collateral
- Market analysis, buyer persona formulation, and competitive intelligence assessments
- Exceptional written business storytelling and speaking skills
- Campaign KPI tracking and analytical performance measurement using CRM tools (HubSpot, Salesforce)
- Operating inside matrixed corporate ecosystems, aligning marketing outputs with legal and product guidelines`
  },
  {
    id: "hr-specialist",
    title: "Human Resources Generalist",
    department: "People & Organization",
    description: `About the Role:
We are searching for an HR Generalist to support employee relations, onboarding programs, regulatory compliance, and performance management initiatives under our corporate governance guidelines.

Required Core Skills:
- Sound understanding of corporate HR policies, labor laws, and industrial standards
- Managing professional compensation, benefits plans, and payroll software interfaces
- Resolving corporate disputes with professional composure, confidentiality, and empathy
- Designing and leading employee development workshops or onboarding briefings
- Excellent communication, listening, and organizational capabilities`
  }
];
