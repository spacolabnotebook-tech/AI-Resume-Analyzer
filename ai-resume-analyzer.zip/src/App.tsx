import React, { useState, useEffect, useRef } from "react";
import {
  Sparkles,
  Briefcase,
  FileText,
  Upload,
  Check,
  AlertCircle,
  Mail,
  Phone,
  Award,
  BookOpen,
  ArrowRight,
  TrendingUp,
  Info,
  ChevronRight,
  RefreshCw,
  Clock,
  User,
  Users,
  Heart
} from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import { jobTemplates, JobTemplate } from "./data/templates";
import { AnalysisPayload } from "./types";
import RatingBar from "./components/RatingBar";
import SuggestionItem from "./components/SuggestionItem";
import PresentationCompanion from "./components/PresentationCompanion";

export default function App() {
  // Mode Selection State
  const [currentMode, setCurrentMode] = useState<"workspace" | "presentation">("workspace");

  // Input States
  const [activeTab, setActiveTab] = useState<"upload" | "text">("upload");
  const [file, setFile] = useState<File | null>(null);
  const [fileBase64, setFileBase64] = useState<string>("");
  const [pastedText, setPastedText] = useState<string>("");
  const [jobDescription, setJobDescription] = useState<string>(jobTemplates[0].description);
  const [selectedTemplateId, setSelectedTemplateId] = useState<string>(jobTemplates[0].id);

  // Analysis States
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisResult, setAnalysisResult] = useState<AnalysisPayload | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Loader Text rotation State
  const [loaderMessageIndex, setLoaderMessageIndex] = useState(0);
  const loaderMessages = [
    "Spinning up local Python sandbox pipeline...",
    "Extracting binary layers from candidate PDF...",
    "Parsing text chunks and standardizing layout...",
    "Feeding criteria to Gemini Cognitive model...",
    "Mapping skills alignment matrices...",
    "Evaluating corporate readiness and cultural alignment indicators...",
    "Formulating prioritized suggestions checklist...",
  ];

  // Drag and drop State
  const [dragActive, setDragActive] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Rotate loading screen tips
  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (isAnalyzing) {
      setLoaderMessageIndex(0);
      interval = setInterval(() => {
        setLoaderMessageIndex((prev) => (prev + 1) % loaderMessages.length);
      }, 3500);
    }
    return () => clearInterval(interval);
  }, [isAnalyzing]);

  // Handle template selection change
  const handleSelectTemplate = (tpl: JobTemplate) => {
    setSelectedTemplateId(tpl.id);
    setJobDescription(tpl.description);
  };

  // Convert File to Base64 String
  const convertToBase64 = (fileObj: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(fileObj);
      reader.onload = () => resolve(reader.result as string);
      reader.onerror = (error) => reject(error);
    });
  };

  // File Input Callbacks
  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const selected = e.target.files[0];
      setFile(selected);
      setErrorMessage(null);
      try {
        const base64 = await convertToBase64(selected);
        setFileBase64(base64);
      } catch (err) {
        setErrorMessage("Failed to process file binary.");
      }
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = async (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);

    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const dropped = e.dataTransfer.files[0];
      setFile(dropped);
      setErrorMessage(null);
      try {
        const base64 = await convertToBase64(dropped);
        setFileBase64(base64);
      } catch (err) {
        setErrorMessage("Failed to convert dropped file structure.");
      }
    }
  };

  const onButtonClick = () => {
    fileInputRef.current?.click();
  };

  // Run Backend Analyze Route
  const triggerAnalysis = async () => {
    setIsAnalyzing(true);
    setErrorMessage(null);

    // Validate inputs
    if (activeTab === "upload" && !file) {
      setErrorMessage("Please select or drop a resume PDF first.");
      setIsAnalyzing(false);
      return;
    }
    if (activeTab === "text" && !pastedText.trim()) {
      setErrorMessage("Please type or paste candidate profile text.");
      setIsAnalyzing(false);
      return;
    }
    if (!jobDescription.trim()) {
      setErrorMessage("Please enter a job description to score against.");
      setIsAnalyzing(false);
      return;
    }

    try {
      const payload: any = {
        jobDescription,
      };

      if (activeTab === "upload") {
        payload.fileBase64 = fileBase64;
        payload.fileName = file?.name;
      } else {
        payload.fileText = pastedText;
      }

      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.error || "Failed to analyze resume. Verify configuration and try again.");
      }

      setAnalysisResult(data.analysis);
      // Scroll to result on smaller views
      setTimeout(() => {
        document.getElementById("results-root")?.scrollIntoView({ behavior: "smooth" });
      }, 100);

    } catch (err: any) {
      console.error(err);
      setErrorMessage(err.message || "An error occurred during evaluation.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const resetWorkspace = () => {
    setFile(null);
    setFileBase64("");
    setPastedText("");
    setAnalysisResult(null);
    setErrorMessage(null);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-white font-sans selection:bg-blue-900 selection:text-blue-100 pb-12 relative overflow-hidden">
      
      {/* Frosted ambient glow background blobs */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute -top-[10%] -left-[10%] w-[60%] h-[60%] rounded-full bg-blue-600/15 blur-[120px]"></div>
        <div className="absolute top-[30%] -right-[15%] w-[50%] h-[50%] rounded-full bg-indigo-600/10 blur-[100px]"></div>
        <div className="absolute -bottom-[10%] left-[20%] w-[40%] h-[40%] rounded-full bg-teal-500/10 blur-[110px]"></div>
      </div>

      {/* Top Banner Applet Bar */}
      <header className="sticky top-0 z-45 bg-white/5 border-b border-white/10 backdrop-blur-md shadow-lg p-4 relative">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-gradient-to-tr from-blue-500 to-teal-400 rounded-xl text-white shadow-lg shadow-blue-500/20">
              <Briefcase className="w-5.5 h-5.5" />
            </div>
            <div className="text-left">
              <h1 className="text-lg md:text-xl font-bold text-white tracking-tight flex items-center gap-2">
                CorporateFit <span className="text-xs font-mono font-bold bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded-full border border-blue-500/30">AI Analyzer</span>
              </h1>
              <p className="text-xs text-white/60">
                Evaluating candidate fit & scoring alignments using Python text extraction and Gemini
              </p>
            </div>
          </div>

          {/* Mode Switcher Segmented Control */}
          <div className="flex bg-slate-900 border border-white/10 p-1 rounded-xl shrink-0">
            <button
              onClick={() => setCurrentMode("workspace")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                currentMode === "workspace"
                  ? "bg-gradient-to-r from-blue-600 to-indigo-600 text-white shadow-md shadow-blue-900/30"
                  : "text-white/60 hover:text-white"
              }`}
            >
              <Briefcase className="w-3.5 h-3.5" />
              Workspace Hub
            </button>
            <button
              onClick={() => setCurrentMode("presentation")}
              className={`px-4 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2 cursor-pointer transition-all ${
                currentMode === "presentation"
                  ? "bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-md shadow-indigo-900/30"
                  : "text-white/60 hover:text-white"
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              6-Presenter Deck Companion
            </button>
          </div>
          
          <div className="flex items-center gap-4 text-xs font-mono text-white/60 shrink-0">
            <span className="flex items-center gap-1.5 px-2.5 py-1 bg-white/5 border border-white/10 rounded-lg">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              Parser Core: Active
            </span>
            <span className="hidden lg:flex items-center gap-1.5 px-2.5 py-1 bg-white/5 border border-white/10 rounded-lg">
              <Clock className="w-3.5 h-3.5" />
              UTC 25-05-2026
            </span>
          </div>
        </div>
      </header>

      {/* Main Workspace Frame */}
      <main className="max-w-7xl mx-auto px-4 mt-6 relative z-10">
        <AnimatePresence mode="wait">
          {currentMode === "presentation" ? (
            <motion.div
              key="presentation-mode"
              initial={{ opacity: 0, scale: 0.98 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 0.98 }}
              transition={{ duration: 0.2 }}
            >
              <PresentationCompanion />
            </motion.div>
          ) : (
            <motion.div
              key="workspace-mode"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 15 }}
              transition={{ duration: 0.2 }}
              className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
            >
          
          {/* LEFT: Target inputs & File setup (Col-12 to Col-5) */}
          <div className="lg:col-span-5 space-y-6">
            
            {/* Template JD quick selectors */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-lg">
              <div className="flex items-center justify-between mb-3.5">
                <span className="text-sm font-semibold text-white flex items-center gap-2">
                  <span className="w-1.5 h-4 bg-blue-500 rounded-xs"></span>
                  Corporate Benchmarks
                </span>
                <span className="text-[10px] font-bold text-white/40 font-mono tracking-wider uppercase">
                  Select Role Preset
                </span>
              </div>
              <div className="grid grid-cols-2 xs:grid-cols-3 sm:grid-cols-5 lg:grid-cols-1 gap-2 max-h-[220px] lg:max-h-none overflow-y-auto">
                {jobTemplates.map((template) => (
                  <button
                    key={template.id}
                    onClick={() => handleSelectTemplate(template)}
                    className={`flex items-center justify-between p-3 rounded-xl border text-left transition-all text-xs font-medium cursor-pointer ${
                      selectedTemplateId === template.id
                        ? "bg-blue-600/20 border-blue-500/50 text-blue-300 shadow-sm"
                        : "bg-white/5 border-white/10 text-white/70 hover:bg-white/10 hover:text-white"
                    }`}
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Briefcase className="w-3.5 h-3.5 shrink-0" />
                      <div className="truncate">
                        <span className="block font-semibold truncate">{template.title}</span>
                        <span className="text-[10px] text-white/40 font-normal">{template.department}</span>
                      </div>
                    </div>
                    {selectedTemplateId === template.id && <Check className="w-4 h-4 shrink-0" />}
                  </button>
                ))}
              </div>
            </div>

            {/* Resume Input Panel */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-lg">
              <div className="flex items-center justify-between border-b border-white/10 pb-3 mb-4">
                <span className="text-sm font-semibold text-white flex items-center gap-2">
                  <span className="w-1.5 h-4 bg-teal-400 rounded-sm"></span>
                  Candidate Portfolio
                </span>
                
                <div className="flex bg-white/5 p-0.5 rounded-lg border border-white/10">
                  <button
                    onClick={() => setActiveTab("upload")}
                    className={`px-3 py-1 cursor-pointer text-xs font-medium rounded-md transition-all ${
                      activeTab === "upload" ? "bg-white/10 text-blue-300 font-semibold shadow-xs" : "text-white/55 hover:text-white"
                    }`}
                  >
                    Upload PDF
                  </button>
                  <button
                    onClick={() => setActiveTab("text")}
                    className={`px-3 py-1 cursor-pointer text-xs font-medium rounded-md transition-all ${
                      activeTab === "text" ? "bg-white/10 text-blue-300 font-semibold shadow-xs" : "text-white/55 hover:text-white"
                    }`}
                  >
                    Paste Text
                  </button>
                </div>
              </div>

              {activeTab === "upload" ? (
                <div>
                  <div
                    onDragEnter={handleDrag}
                    onDragOver={handleDrag}
                    onDragLeave={handleDrag}
                    onDrop={handleDrop}
                    className={`border-2 border-dashed rounded-xl p-5 flex flex-col items-center justify-center text-center transition-all min-h-[170px] ${
                      dragActive
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-white/20 bg-white/5 hover:bg-white/8 hover:border-white/30"
                    }`}
                  >
                    <input
                      ref={fileInputRef}
                      type="file"
                      accept=".pdf"
                      onChange={handleFileChange}
                      className="hidden"
                    />
                    <Upload className="w-8 h-8 text-white/30 mb-3" />
                    <p className="text-xs font-medium text-white/80 mb-1">
                      Drag and drop candidate's resume PDF
                    </p>
                    <p className="text-[10px] text-white/40 mb-3.5">
                      Max file size: 10MB. Formats: PDF only
                    </p>
                    <button
                      type="button"
                      onClick={onButtonClick}
                      className="px-4 py-1.5 bg-white/10 border border-white/10 rounded-lg text-xs font-semibold text-white hover:bg-white/20 hover:border-white/20 transition-all cursor-pointer"
                    >
                      Browse Files
                    </button>
                  </div>
                  
                  {file && (
                    <motion.div
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      className="mt-3.5 p-3.5 bg-blue-500/15 border border-blue-500/30 rounded-xl flex items-center justify-between text-xs"
                    >
                      <div className="flex items-center gap-2.5 overflow-hidden">
                        <FileText className="w-5 h-5 text-blue-400 shrink-0" />
                        <div className="truncate">
                          <span className="block font-medium text-blue-200 truncate">{file.name}</span>
                          <span className="text-[10px] text-white/40">
                            {(file.size / (1024 * 1024)).toFixed(2)} MB • Ready to analyze
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => {
                          setFile(null);
                          setFileBase64("");
                        }}
                        className="text-amber-400 hover:text-rose-400 font-medium px-2 py-1 cursor-pointer transition-colors"
                      >
                        Remove
                      </button>
                    </motion.div>
                  )}
                </div>
              ) : (
                <div className="space-y-2">
                  <textarea
                    rows={8}
                    value={pastedText}
                    onChange={(e) => setPastedText(e.target.value)}
                    placeholder="Paste the candidate's resume text, experience logs, and educational background directly here..."
                    className="w-full text-xs p-3 border border-white/10 rounded-xl bg-white/5 text-white placeholder-white/30 focus:outline-hidden focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all font-sans leading-relaxed"
                  />
                  <p className="text-[10px] text-white/40 text-right">
                    Supports plain text inputs from any document source
                  </p>
                </div>
              )}
            </div>

            {/* Targeted Job Description edit box */}
            <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-5 shadow-lg">
              <span className="text-sm font-semibold text-white flex items-center gap-2 mb-3.5">
                <span className="w-1.5 h-4 bg-indigo-500 rounded-sm"></span>
                Job Description (Recruiting Criteria)
              </span>
              <textarea
                rows={9}
                value={jobDescription}
                onChange={(e) => {
                  setJobDescription(e.target.value);
                  setSelectedTemplateId(""); // clear template highlight since they modified
                }}
                className="w-full text-xs p-3.5 border border-white/10 rounded-xl bg-white/5 text-white placeholder-white/30 focus:outline-hidden focus:ring-1 focus:ring-blue-500 focus:border-blue-500 transition-all font-mono leading-relaxed"
                placeholder="Paste the targeted company job requirements, tech frameworks, required education degrees and cultural parameters here..."
              />
              <div className="flex items-center justify-between mt-2.5 text-[10px] text-white/40">
                <span>Character Count: {jobDescription.length}</span>
                <span>Includes skills matching algorithms</span>
              </div>
            </div>

            {/* Error Message bar */}
            {errorMessage && (
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="p-3.5 bg-rose-500/10 border border-rose-500/30 rounded-xl flex gap-3 text-xs text-rose-200 leading-relaxed"
              >
                <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
                <div>
                  <span className="font-semibold block mb-0.5 text-rose-300">Validation Alert</span>
                  {errorMessage}
                </div>
              </motion.div>
            )}

            {/* Evaluating Actions Trigger row */}
            <div className="flex gap-4.5 pt-1.5">
              <button
                type="button"
                onClick={triggerAnalysis}
                disabled={isAnalyzing}
                className="grow py-3.5 bg-blue-600 text-white rounded-xl text-sm font-semibold shadow-lg shadow-blue-900/40 hover:bg-blue-500 transition-all duration-150 disabled:opacity-50 flex items-center justify-center gap-2 cursor-pointer"
              >
                {isAnalyzing ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    Evaluating Profile...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4.5 h-4.5" />
                    Run Smart Diagnostics
                  </>
                )}
              </button>
              
              <button
                type="button"
                onClick={resetWorkspace}
                className="px-4 py-3.5 bg-white/5 border border-white/10 rounded-xl text-xs font-semibold text-white/80 hover:bg-white/10 transition-colors cursor-pointer"
                title="Reset workspace variables"
              >
                Reset
              </button>
            </div>

          </div>

          {/* MAIN OUTPUT AREA: Analysis Results (Col-12 to Col-7) */}
          <div id="results-root" className="lg:col-span-7">
            
            <AnimatePresence mode="wait">
              
              {/* Scenario 1: Still Analyzing - Custom Animated Loader */}
              {isAnalyzing && (
                <motion.div
                  key="analyzing-loader"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10 flex flex-col items-center justify-center text-center shadow-lg min-h-[480px] space-y-6"
                >
                  <div className="relative w-16 h-16 flex items-center justify-center">
                    <div className="absolute inset-0 border-4 border-white/10 rounded-full"></div>
                    <div className="absolute inset-0 border-4 border-t-blue-500 border-r-blue-500 rounded-full animate-spin"></div>
                    <Sparkles className="w-6 h-6 text-blue-400 animate-pulse" />
                  </div>
                  
                  <div className="space-y-2.5 max-w-sm">
                    <h3 className="font-semibold text-white text-base md:text-lg">Compiling Alignment Profile</h3>
                    <p className="text-xs text-white/80 bg-white/5 px-3.5 py-1.5 rounded-full border border-white/10 inline-block font-mono animate-pulse">
                      {loaderMessages[loaderMessageIndex]}
                    </p>
                    <p className="text-xs text-white/40 pt-2 leading-relaxed">
                      Our Python extraction engine reads PDF pages directly and outputs text payloads, while Gemini processes metrics alignment scoring. This may take up to 10 seconds.
                    </p>
                  </div>
                </motion.div>
              )}

              {/* Scenario 2: Active results view */}
              {!isAnalyzing && analysisResult && (
                <motion.div
                  key="analysis-loaded"
                  initial={{ opacity: 0, y: 15 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0 }}
                  className="space-y-6"
                >
                  
                  {/* parsed Info Overview (Extracted from candidate data) */}
                  <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg space-y-4">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-3 border-b border-white/10 pb-4">
                      <div>
                        <span className="text-[10px] font-bold text-blue-400 font-mono tracking-wider uppercase drop-shadow-xs">
                          Identified Profile Credentials
                        </span>
                        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2 mt-0.5">
                          <User className="w-5.5 h-5.5 text-white/40 shrink-0" />
                          {analysisResult.candidate.name || "Extracted Applicant"}
                        </h2>
                        {analysisResult.candidate.currentTitle && (
                          <p className="text-xs text-white/50 font-medium">
                            {analysisResult.candidate.currentTitle}
                          </p>
                        )}
                      </div>
                      <div className="flex flex-col text-white/50 text-xs space-y-1">
                        {analysisResult.candidate.email && (
                          <span className="flex items-center gap-1.5">
                            <Mail className="w-3.5 h-3.5 text-white/30" />
                            {analysisResult.candidate.email}
                          </span>
                        )}
                        {analysisResult.candidate.phone && (
                          <span className="flex items-center gap-1.5">
                            <Phone className="w-3.5 h-3.5 text-white/30" />
                            {analysisResult.candidate.phone}
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-12 gap-5.5">
                      <div className="md:col-span-8 space-y-3">
                        <span className="text-xs font-semibold text-white/40 block uppercase tracking-wider font-mono">
                          Brief Profile Summary
                        </span>
                        <p className="text-xs md:text-sm text-white/70 leading-relaxed font-normal bg-white/5 border border-white/5 p-3.5 rounded-xl">
                          "{analysisResult.candidate.summary}"
                        </p>
                      </div>

                      <div className="md:col-span-4 bg-white/5 border border-white/10 p-4 rounded-2xl flex flex-col justify-between">
                        <div className="space-y-2">
                          <span className="text-xs font-semibold text-white/40 block uppercase tracking-wider font-mono">
                            Career Span Estimate
                          </span>
                          <span className="text-3xl font-bold bg-gradient-to-tr from-blue-400 to-teal-400 bg-clip-text text-transparent tracking-tight block">
                            {analysisResult.candidate.yearsOfExperience} <span className="text-xs font-semibold text-white/45">Years</span>
                          </span>
                        </div>
                        {analysisResult.candidate.education && analysisResult.candidate.education.length > 0 && (
                          <div className="mt-3.5 pt-3.5 border-t border-white/10">
                            <span className="text-[10px] font-bold text-white/40 font-mono block mb-1 uppercase tracking-wider">
                              Academic Credentials
                            </span>
                            <div className="flex flex-wrap gap-1">
                              {analysisResult.candidate.education.map((edu, idx) => (
                                <span key={idx} className="inline-flex items-center px-2 py-0.5 rounded-sm bg-white/5 border border-white/10 text-[10px] text-white/70 truncate max-w-full">
                                  <BookOpen className="w-2.5 h-2.5 shrink-0 text-white/40 mr-1" />
                                  <span className="truncate">{edu}</span>
                                </span>
                              ))}
                            </div>
                          </div>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* BENTO ROW: Match Percentage Metric Gauge */}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Gauge 1: Specific Job Description Matching Score */}
                    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-sm font-semibold text-white flex items-center gap-2">
                            <span className="w-1.5 h-4 bg-blue-500 rounded-sm"></span>
                            JD Requirements Match
                          </span>
                          <span className="text-[10px] font-mono font-bold bg-blue-500/10 text-blue-300 px-2 py-0.5 border border-blue-500/20 rounded-full">
                            ATS Score
                          </span>
                        </div>
                        
                        <div className="flex items-center gap-5 my-3">
                          <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
                            {/* Circular track */}
                            <svg className="w-full h-full rotate-270 transform">
                              <circle cx="48" cy="48" r="40" strokeWidth="6" stroke="rgba(255,255,255,0.06)" fill="transparent" />
                              <motion.circle
                                cx="48" cy="48" r="40" strokeWidth="6"
                                stroke={analysisResult.jobMatching.matchScore >= 75 ? "#34d399" : analysisResult.jobMatching.matchScore >= 50 ? "#60a5fa" : "#fbbf24"}
                                strokeDasharray="251.2"
                                strokeLinecap="round"
                                fill="transparent"
                                initial={{ strokeDashoffset: "251.2" }}
                                animate={{ strokeDashoffset: (251.2 - (251.2 * analysisResult.jobMatching.matchScore) / 100).toString() }}
                                transition={{ duration: 1, ease: "easeOut" }}
                              />
                            </svg>
                            <span className="absolute text-xl font-bold font-mono text-white">
                              {analysisResult.jobMatching.matchScore}%
                            </span>
                          </div>

                          <div className="space-y-1">
                            <h4 className="font-semibold text-white text-sm">Skills Alignment Evaluation</h4>
                            <p className="text-xs text-white/50 leading-relaxed font-normal">
                              Aligns requested certifications, operational responsibilities, and toolsets listed in the targeted criteria.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t border-white/10 bg-white/3 -mx-6 -mb-6 p-5 rounded-b-3xl">
                        <span className="text-[10px] font-extrabold text-white/40 font-mono uppercase tracking-wider block mb-1">
                          Alignment Overview Brief
                        </span>
                        <p className="text-xs text-white/70 leading-normal font-sans">
                          {analysisResult.jobMatching.fitSummary}
                        </p>
                      </div>
                    </div>

                    {/* Gauge 2: Corporate Sector Suitability Score */}
                    <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg flex flex-col justify-between">
                      <div>
                        <div className="flex items-center justify-between mb-4">
                          <span className="text-sm font-semibold text-white flex items-center gap-2">
                            <span className="w-1.5 h-4 bg-emerald-500 rounded-sm"></span>
                            Corporate Sector Fit
                          </span>
                          <span className={`text-[10px] font-mono font-bold px-2 py-0.5 border rounded-full ${
                            analysisResult.corporateSectorFit.suitabilityScore >= 75
                              ? "bg-emerald-500/10 text-emerald-300 border-emerald-550/20"
                              : "bg-amber-500/10 text-amber-300 border-amber-550/20"
                          }`}>
                            Fitness Level
                          </span>
                        </div>

                        <div className="flex items-center gap-5 my-3">
                          <div className="relative w-24 h-24 flex items-center justify-center shrink-0">
                            <svg className="w-full h-full rotate-270 transform">
                              <circle cx="48" cy="48" r="40" strokeWidth="6" stroke="rgba(255,255,255,0.06)" fill="transparent" />
                              <motion.circle
                                cx="48" cy="48" r="40" strokeWidth="6"
                                stroke={analysisResult.corporateSectorFit.suitabilityScore >= 75 ? "#34d399" : "#fbbf24"}
                                strokeDasharray="251.2"
                                strokeLinecap="round"
                                fill="transparent"
                                initial={{ strokeDashoffset: "251.2" }}
                                animate={{ strokeDashoffset: (251.2 - (251.2 * analysisResult.corporateSectorFit.suitabilityScore) / 100).toString() }}
                                transition={{ duration: 1, ease: "easeOut" }}
                              />
                            </svg>
                            <span className="absolute text-xl font-bold font-mono text-white">
                              {analysisResult.corporateSectorFit.suitabilityScore}%
                            </span>
                          </div>

                          <div className="space-y-1">
                            <span className="text-[10px] text-emerald-300 bg-emerald-500/10 px-2 py-0.5 border border-emerald-500/20 font-semibold uppercase tracking-wider font-mono rounded-sm inline-block">
                              {analysisResult.corporateSectorFit.overallStatus}
                            </span>
                            <h4 className="font-semibold text-white text-sm mt-1">Recruitment Ready</h4>
                            <p className="text-xs text-white/50 leading-relaxed font-normal">
                              Determines professional posture, project execution clarity, and structural communication styles.
                            </p>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4 pt-4 border-t border-white/10 bg-white/3 -mx-6 -mb-6 p-5 rounded-b-3xl">
                        <span className="text-[10px] font-extrabold text-white/40 font-mono uppercase tracking-wider block mb-1">
                          Corporate Soft Skills Analysis
                        </span>
                        <p className="text-xs text-white/70 leading-normal font-sans">
                          {analysisResult.corporateSectorFit.analysisOverview}
                        </p>
                      </div>
                    </div>

                  </div>

                  {/* Corporate Fit Dimension Breakdown Bars */}
                  <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg space-y-4">
                    <span className="text-sm font-semibold text-white flex items-center gap-2">
                      <span className="w-1.5 h-4 bg-emerald-500 rounded-sm"></span>
                      Corporate Competency Scores
                    </span>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      {analysisResult.corporateSectorFit.dimensions.map((dimension, idx) => (
                        <RatingBar
                          key={idx}
                          name={dimension.name}
                          score={dimension.score}
                          feedback={dimension.feedback}
                        />
                      ))}
                    </div>
                  </div>

                  {/* Skills Cloud Comparison tagging panel */}
                  <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg space-y-6">
                    <div className="flex items-center justify-between border-b border-white/10 pb-3">
                      <span className="text-sm font-semibold text-white flex items-center gap-2">
                        <span className="w-1.5 h-4 bg-blue-500 rounded-sm"></span>
                        Key Skillset Comparison & Tag Matcher
                      </span>
                      <span className="text-[10px] text-white/40 font-mono tracking-wider font-bold uppercase">
                        JD Requirements Check
                      </span>
                    </div>

                    {/* Tag Cloud 1: Matched values */}
                    <div className="space-y-2.5">
                      <span className="text-xs font-semibold text-emerald-300 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-emerald-400 inline-block"></span>
                        MATCHED REQUIREMENTS ({analysisResult.jobMatching.matchedSkills.length})
                      </span>
                      {analysisResult.jobMatching.matchedSkills.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {analysisResult.jobMatching.matchedSkills.map((skill, idx) => (
                            <span key={idx} className="inline-flex items-center px-2.5 py-1 rounded-lg bg-emerald-500/10 border border-emerald-500/20 text-xs font-medium text-emerald-300">
                              <Check className="w-3.5 h-3.5 mr-1" />
                              {skill}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-white/40 italic pb-1">No exact key skillset intersections matched. Try optimizing terms or uploading target profile.</p>
                      )}
                    </div>

                    {/* Tag Cloud 2: Missing skills */}
                    <div className="space-y-2.5 pt-2 border-t border-white/10">
                      <span className="text-xs font-semibold text-amber-300 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-amber-400 inline-block animate-pulse"></span>
                        CRITICAL RECRUITMENT DEFICITS ({analysisResult.jobMatching.missingSkills.length})
                      </span>
                      {analysisResult.jobMatching.missingSkills.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {analysisResult.jobMatching.missingSkills.map((skill, idx) => (
                            <span key={idx} className="inline-flex items-center px-2.5 py-1 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs font-medium text-amber-300">
                              <Info className="w-3.5 h-3.5 mr-1 text-amber-400" />
                              {skill}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-white/40 italic pb-1">Excellent match! The applicant highlights all critical requirements listed in the profile criteria.</p>
                      )}
                    </div>

                    {/* Tag Cloud 3: Extra valuable skills */}
                    <div className="space-y-2.5 pt-2 border-t border-white/10">
                      <span className="text-xs font-semibold text-violet-300 flex items-center gap-1.5">
                        <span className="w-2 h-2 rounded-full bg-violet-400 inline-block animate-pulse"></span>
                        PREMIUM EXTRA BONUS SKILLS ({analysisResult.jobMatching.bonusSkills.length})
                      </span>
                      {analysisResult.jobMatching.bonusSkills.length > 0 ? (
                        <div className="flex flex-wrap gap-2">
                          {analysisResult.jobMatching.bonusSkills.map((skill, idx) => (
                            <span key={idx} className="inline-flex items-center px-2.5 py-1 rounded-lg bg-violet-500/10 border border-violet-500/25 text-xs font-medium text-violet-350">
                              <Sparkles className="w-3.5 h-3.5 mr-1 text-violet-400" />
                              {skill}
                            </span>
                          ))}
                        </div>
                      ) : (
                        <p className="text-xs text-white/40 italic">No supplemental skills found that differ from core JD items.</p>
                      )}
                    </div>

                    {/* Candidate extracted skills */}
                    {analysisResult.extractedSkills && analysisResult.extractedSkills.length > 0 && (
                      <div className="pt-3 border-t border-white/10 space-y-2">
                        <span className="text-xs font-semibold text-white/40 block uppercase tracking-wider font-mono">
                          Complete Parsed Profile Competencies ({analysisResult.extractedSkills.length})
                        </span>
                        <div className="flex flex-wrap gap-1.5">
                          {analysisResult.extractedSkills.map((skill, idx) => (
                            <span key={idx} className="text-[10px] px-2 py-0.5 rounded-sm bg-white/5 border border-white/10 text-white/70">
                              {skill}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>

                  {/* SUGGESTIONS CHECKLIST ROW */}
                  <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 shadow-lg space-y-4">
                    <div>
                      <h3 className="text-sm font-semibold text-white flex items-center gap-2">
                        <span className="w-1.5 h-4 bg-orange-500 rounded-sm"></span>
                        Actionable Improvement Suggestions Checklist
                      </h3>
                      <p className="text-xs text-white/55 leading-relaxed mt-1 font-normal">
                        Select and check off task recommendations as you refine criteria. Click the dropdown arrows to discover "Why this matters."
                      </p>
                    </div>

                    <div className="space-y-3 pt-2">
                      {analysisResult.improvementSuggestions.map((item, index) => (
                        <SuggestionItem
                          key={index}
                          item={item}
                          index={index}
                        />
                      ))}
                    </div>
                  </div>

                </motion.div>
              )}

              {/* Scenario 3: Initial Empty State */}
              {!isAnalyzing && !analysisResult && (
                <motion.div
                  key="empty-state"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-10 flex flex-col items-center justify-center text-center shadow-lg min-h-[480px] space-y-4"
                >
                  <div className="w-16 h-16 bg-white/5 border border-white/10 rounded-full flex items-center justify-center text-white/40">
                    <FileText className="w-7 h-7" />
                  </div>
                  <div className="space-y-2 max-w-sm">
                    <h3 className="font-semibold text-white text-base md:text-lg">Candidate Analysis Workspace</h3>
                    <p className="text-xs text-white/50 leading-relaxed">
                      Upload your applicant's portfolio resume PDF or load standard plain credentials, choose your benchmark target job description, and run diagnostic compilations to view corporate matrix parameters here.
                    </p>
                  </div>
                  
                  {/* Small tips grid inside the empty state */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5 pt-6 w-full max-w-md text-left">
                    <div className="p-3.5 bg-white/5 border border-white/10 rounded-xl flex items-start gap-2.5">
                      <div className="p-1 px-1.5 bg-blue-500/10 border border-blue-500/20 text-blue-300 text-[10px] font-mono font-bold rounded-lg shrink-0 mt-0.5">
                        Python
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-white block">PDF Extraction Core</span>
                        <p className="text-[10px] text-white/55 leading-relaxed mt-0.5">
                          Runs standard python libraries server-side to decompress and extract rich fonts/text directly.
                        </p>
                      </div>
                    </div>

                    <div className="p-3.5 bg-white/5 border border-white/10 rounded-xl flex items-start gap-2.5">
                      <div className="p-1 px-1.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-300 text-[10px] font-mono font-bold rounded-lg shrink-0 mt-0.5">
                        AI
                      </div>
                      <div>
                        <span className="text-xs font-semibold text-white block">Fitment Scoring Matrices</span>
                        <p className="text-[10px] text-white/55 leading-relaxed mt-0.5">
                          Evaluates soft corporate presentation parameters and alignment scores using high-level structured schemas.
                        </p>
                      </div>
                    </div>
                  </div>
                </motion.div>
              )}

            </AnimatePresence>

          </div>

        </motion.div>
      )}
    </AnimatePresence>
  </main>

      {/* Corporate Compliance elegant Footer */}
      <footer className="mt-16 text-center text-[11px] text-white/40 border-t border-white/10 max-w-7xl mx-auto pt-6 px-4">
        <p className="flex items-center justify-center gap-1.5 leading-snug text-white/40">
          Build powered by Google AI Studio • Designed as an elegant, fast, offline-first resume evaluation utility.
        </p>
        <p className="text-[10px] text-white/25 mt-1">
          Development Port: 3000 • Security Sandbox active • Powered by Node.js & Python integrations • Click "Reset" to start fresh.
        </p>
      </footer>
    </div>
  );
}
