import express from "express";
import path from "path";
import fs from "fs";
import { execFile } from "child_process";
import { GoogleGenAI, Type } from "@google/genai";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

// Initialize Express
const app = express();
const PORT = 3000;

// Maximum payload size for resume files (10MB)
app.use(express.json({ limit: "15mb" }));

// Initialize Gemini Client
const apiKey = process.env.GEMINI_API_KEY;
const ai = new GoogleGenAI({
  apiKey: apiKey,
  httpOptions: {
    headers: {
      "User-Agent": "aistudio-build",
    },
  },
});

// Helper: Run Python script to analyze NLP and ML metrics
function analyzeResumeWithPython(resumePathOrText: string, isPdf: boolean, jdText: string): Promise<any> {
  return new Promise((resolve, reject) => {
    const pythonScriptPath = path.join(process.cwd(), "server", "analyze_resume.py");
    
    // Create temp files to prevent argument overflow (E2BIG)
    const jdTempPath = path.join(process.cwd(), `jd_${Date.now()}_temp.txt`);
    let resumeTempPath = resumePathOrText;
    
    try {
      fs.writeFileSync(jdTempPath, jdText, "utf-8");
      
      if (!isPdf) {
        resumeTempPath = path.join(process.cwd(), `resume_${Date.now()}_temp.txt`);
        fs.writeFileSync(resumeTempPath, resumePathOrText, "utf-8");
      }
    } catch (e: any) {
      return reject(new Error(`Failed writing temporary files for NLP analysis: ${e.message}`));
    }

    execFile(
      "python3",
      [pythonScriptPath, resumeTempPath, jdTempPath],
      { maxBuffer: 15 * 1024 * 1024 },
      (error, stdout, stderr) => {
        // Asynchronously clean up custom temp files
        try {
          if (fs.existsSync(jdTempPath)) fs.unlinkSync(jdTempPath);
          if (!isPdf && fs.existsSync(resumeTempPath)) fs.unlinkSync(resumeTempPath);
        } catch (cleanupError) {
          console.error("Temp cleanup error:", cleanupError);
        }

        if (error) {
          console.error("Python analysis pipeline error:", stderr || error.message);
          return reject(new Error(stderr || error.message || "Failed running NLP/ML pipeline in Python."));
        }

        try {
          const result = JSON.parse(stdout);
          resolve(result);
        } catch (jsonError) {
          console.error("JSON parsing error from Python stdout:", jsonError);
          reject(new Error("Python NLP script returned invalid JSON layout."));
        }
      }
    );
  });
}

// Structured JSON Schema for Gemini response
const ResponseSchema = {
  type: Type.OBJECT,
  properties: {
    candidate: {
      type: Type.OBJECT,
      properties: {
        name: { type: Type.STRING, description: "Extracted candidate name" },
        email: { type: Type.STRING, description: "Extracted email address" },
        phone: { type: Type.STRING, description: "Extracted phone number" },
        currentTitle: { type: Type.STRING, description: "Current professional level/title" },
        summary: { type: Type.STRING, description: "A concise, engaging 2-sentence executive summary of the candidate's background" },
        yearsOfExperience: { type: Type.NUMBER, description: "Estimated total years of relevant professional experience" },
        education: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Degrees, institutions, or certifications"
        }
      },
      required: ["name", "email", "phone", "summary"]
    },
    extractedSkills: {
      type: Type.ARRAY,
      items: { type: Type.STRING },
      description: "Comprehensive list of technical, commercial, or professional skills found in the profile"
    },
    corporateSectorFit: {
      type: Type.OBJECT,
      properties: {
        overallStatus: { type: Type.STRING, description: "Labels: Highly Corporate Material, Fit with Dynamic Gaps, Requires Corporate Readiness Work" },
        suitabilityScore: { type: Type.INTEGER, description: "0-100 score on how ready they are for modern corporate environments" },
        analysisOverview: { type: Type.STRING, description: "In-depth briefing of candidate's readiness for the corporate landscape, addressing collaboration, work structures, and professional presentation." },
        dimensions: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING, description: "One of: 'Business Etiquette', 'Stakeholder Alignment', 'Business Communication', 'Problem Solving', 'Adaptability & Resilience' " },
              score: { type: Type.INTEGER, description: "Dimension rating from 1 to 10" },
              feedback: { type: Type.STRING, description: "Specific insights for this competency dimension based on their history" }
            },
            required: ["name", "score", "feedback"]
          }
        }
      },
      required: ["overallStatus", "suitabilityScore", "analysisOverview", "dimensions"]
    },
    jobMatching: {
      type: Type.OBJECT,
      properties: {
        matchScore: { type: Type.INTEGER, description: "0-100 overall fit score comparing accomplishments against the provided job description" },
        matchedSkills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Skills listed in the JD that the applicant successfully features"
        },
        missingSkills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Crucial requirements or skills from the JD that the candidate lacks"
        },
        bonusSkills: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Valuable skills she/he possesses that enrich the application but weren't strictly requested in the JD"
        },
        fitSummary: { type: Type.STRING, description: "A summary evaluation of their alignment with the specific hiring criteria" }
      },
      required: ["matchScore", "matchedSkills", "missingSkills", "bonusSkills", "fitSummary"]
    },
    improvementSuggestions: {
      type: Type.ARRAY,
      items: {
        type: Type.OBJECT,
        properties: {
          category: { type: Type.STRING, description: "Category label: Resume Optimization, Skill Acquisition, Corporate Style & Formatting, Professional Branding" },
          suggestion: { type: Type.STRING, description: "Direct, constructive recommendation" },
          why: { type: Type.STRING, description: "Explanation of how this adjustments boosts hiring success" },
          priority: { type: Type.STRING, description: "High, Medium, Info" }
        },
        required: ["category", "suggestion", "why", "priority"]
      },
      description: "A set of actionable, custom instructions to optimize their resume or bridge gaps"
    }
  },
  required: [
    "candidate",
    "extractedSkills",
    "corporateSectorFit",
    "jobMatching",
    "improvementSuggestions"
  ]
};

// API Route: Check keys and platform setup
app.get("/api/health", (req, res) => {
  res.json({
    status: "ok",
    hasApiKey: !!process.env.GEMINI_API_KEY,
  });
});

// API Route: Resume Analysis Engine using Python NLP/ML Model
app.post("/api/analyze", async (req, res) => {
  const { fileBase64, fileName, fileText, jobDescription } = req.body;

  if (!jobDescription) {
    return res.status(400).json({ error: "Missing job description for alignment." });
  }

  let tempPdfPath = "";
  let isPdf = false;
  let targetInput = fileText || "";

  try {
    // If a Base64 encoded file input is provided, handle extraction processes
    if (fileBase64 && fileName) {
      isPdf = fileName.toLowerCase().endsWith(".pdf");
      const cleanBase64 = fileBase64.replace(/^data:application\/pdf;base64,/, "");
      const buffer = Buffer.from(cleanBase64, "base64");

      if (isPdf) {
        tempPdfPath = path.join(process.cwd(), `resume_${Date.now()}_temp.pdf`);
        fs.writeFileSync(tempPdfPath, buffer);
        targetInput = tempPdfPath;
        console.log(`Analyzing: spawned Python parsing on PDF temp path ${tempPdfPath}`);
      } else {
        // Fallback for plain .txt
        targetInput = buffer.toString("utf-8");
      }
    }

    // Verify there is content to analyze
    if (!targetInput || targetInput.trim().length === 0) {
      throw new Error(
        "Could not detect any content text in the uploaded profile. Please paste your profile text or ensure your PDF file contains digital selectable fonts."
      );
    }

    console.log("Triggering Python NLP/ML analysis pipeline...");
    // Execute the local python text processing, tokenization, TF-IDF vectorization and soft-skills modeling
    const payload = await analyzeResumeWithPython(targetInput, isPdf, jobDescription);
    
    console.log("Python NLP evaluation successfully computed! Returning payload structured criteria.");
    res.json({ success: true, analysis: payload });

  } catch (error: any) {
    console.error("Analysis Exception:", error);
    res.status(500).json({
      success: false,
      error: error.message || "An error occurred during Python resume evaluation.",
    });
  } finally {
    // Delete temp file asynchronously if created
    if (tempPdfPath && fs.existsSync(tempPdfPath)) {
      fs.unlink(tempPdfPath, (err) => {
        if (err) console.error("Failed to delete temporary PDF file:", tempPdfPath, err);
      });
    }
  }
});

// Configure client environment & routing
async function initServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode - Use Vite Dev Server Middleware
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
    console.log("Vite development middleware mounted successfully.");
  } else {
    // Production Mode - Serve static files from compiled dist
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
    console.log("Serving compiled static assets from dist/ directory.");
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Resume Analyzer App is active at: http://localhost:${PORT}`);
    console.log(`Port binding: 3000. Access allowed via ingress reverse-proxy.`);
  });
}

initServer().catch((error) => {
  console.error("Critical: Failed to boot Express application server:", error);
});
